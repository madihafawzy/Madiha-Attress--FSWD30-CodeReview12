<footer class="blog-footer">
		<div class="row">
					<div class="col-lg-2 col-md-2 col-2 footer_text">
						<h4>Facebook</h4>
					</div>
					<div class="col-lg-2 col-md-2 col-2 footer_text">
						<h4>Twitter</h4>
					</div>
					<div class="col-lg-2 col-md-2 col-2 footer_text">
						<h4>Instagram</h4>
					</div>
					<div class="col-lg-2 col-md-2 col-2 footer_text">
						<h4>Google</h4>
					</div>
					<div class="col-lg-2 col-md-2 col-2 footer_text">
						<h4>Youtube</h4>
					</div>
					<div class="col-lg-2 col-md-2 col-2 footer_text">
						<h4>Blogloving</h4>
					</div>
				</div>
     <p> &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?> </p>
     <p>
       <a href="#">Back to top</a>
     </p>
   </footer>
   <?php wp_footer(); ?>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
 </body>
</html>

